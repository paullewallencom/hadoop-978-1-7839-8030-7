#!/bin/bash
while true;
do
curl
"http://download.finance.yahoo.com/d/quotes.csv?s=RHT,MSFT,GOOG,INFY&f=d1t1
sa";
sleep 300;
done
