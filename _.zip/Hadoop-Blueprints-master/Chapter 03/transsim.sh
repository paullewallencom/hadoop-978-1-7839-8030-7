
#!/bin/bash
# This script opens 4 terminal windows.
while [ true ]
do
echo 1 2 $RANDOM 
sleep 1
done
